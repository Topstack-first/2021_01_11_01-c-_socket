## server and client using WinSock    
    
The server program allows multiple clients to chat with each other by using select(). Any message a client sends to the server gets broadcasted to all connected clients.    
    
The client program has a GUI!    
![client gui screenshot](screenshots/clientgui1.png)    
![client gui screenshot](screenshots/clientgui2.png)    
    
---
very first version (no GUI :( )    
![screenshot of the server and 2 clients](screenshots/screenshot.png)    