# c-socket-tcp-select
Simple tcp/ip client/server using socket select and pseudo parallelism in C
