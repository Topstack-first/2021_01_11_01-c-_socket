for running server:
chatserver port
e.g.
chatserver 2222

for running client
chatclient -p port ServerAddress
e.g.
chatclient -p 2222 127.0.0.1
