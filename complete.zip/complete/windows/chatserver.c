﻿#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <winsock2.h>

#pragma comment(lib, "Ws2_32.lib")

#define BUFSIZE 4096
#define MAX_CLIENT_NUM 20 
void ErrorHandling(char* message);

typedef struct peerInfo {
	SOCKADDR_IN Socket;
	SOCKET fd;
	char* nickname;
}peerInfo;

int main(int argc, char** argv) {
	WSADATA wsaData;
	SOCKET hServSock, hClntSock;
	SOCKADDR_IN servAddr, clntAddr;
	peerInfo peerArray[MAX_CLIENT_NUM];
	fd_set reads, temps;

	int clntLen, strLen;
	int CheckPeerNumber = 0;
	char* quitPeer_Nickname;
	char message[BUFSIZE];

	TIMEVAL timeout; // the same as struct timeval timeout;

	if (argc != 2) {
		printf("Usage : %s <port>\n", argv[0]);
		exit(1);
	}

	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) /* Load Winsock 2.2 DLL */
		ErrorHandling("WSAStartup() error!");

	hServSock = socket(PF_INET, SOCK_STREAM, 0);

	if (hServSock == INVALID_SOCKET)
		ErrorHandling("socket() error");

	servAddr.sin_family = AF_INET;
	servAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servAddr.sin_port = htons(atoi(argv[1]));

	if (bind(hServSock, (SOCKADDR*)&servAddr, sizeof(servAddr)) == SOCKET_ERROR)
		ErrorHandling("bind() error");
	if (listen(hServSock, 5) == SOCKET_ERROR)
		ErrorHandling("listen() error");

	FD_ZERO(&reads);
	FD_SET(hServSock, &reads);

	while (1) 
	{
		temps = reads;
		timeout.tv_sec = 5;
		timeout.tv_usec = 0;

		for (int i = 0; i < BUFSIZE; i++)
			message[i] = 0; 

		if (select(0, &temps, 0, 0, &timeout) == SOCKET_ERROR)
			ErrorHandling("select() error");

		for (int arrIndex = 0; arrIndex < reads.fd_count; arrIndex++) { 
			if (FD_ISSET(reads.fd_array[arrIndex], &temps)) {
				if (reads.fd_array[arrIndex] == hServSock) { 
					clntLen = sizeof(clntAddr);
					hClntSock = accept(hServSock, (SOCKADDR*)&clntAddr, &clntLen);

					FD_SET(hClntSock, &reads);
					size_t nickSize = sprintf(message, "guest%d\0", hClntSock);

					peerArray[CheckPeerNumber].nickname = (char*)malloc(sizeof((int)nickSize));
					peerArray[CheckPeerNumber].fd = hClntSock;
					peerArray[CheckPeerNumber].Socket = clntAddr;
					strcpy(peerArray[CheckPeerNumber].nickname, message);

					//printf(peerArray[CheckPeerNumber].nickname);
					//printf(" connected\n");
					
					printf("server is ready to read from socket %d\n",hClntSock);
					printf("server is ready to write from socket %d\n", hClntSock);
					
					send(hClntSock, "connected as ", strlen("connected as "), 0);
					send(hClntSock, peerArray[CheckPeerNumber].nickname, strlen(peerArray[CheckPeerNumber].nickname), 0);
					send(hClntSock, "\n", strlen("\n"), 0);

					CheckPeerNumber++;

					for (int i = 1; i < reads.fd_count - 1; i++) {
						send(reads.fd_array[i], peerArray[CheckPeerNumber - 1].nickname, strlen(peerArray[CheckPeerNumber - 1].nickname), 0);
						send(reads.fd_array[i], " login\n", strlen(" login\n"), 0);
					} 
				}
				else { 
					SOCKET hRecvClientSocket = reads.fd_array[arrIndex];
					strLen = recv(hRecvClientSocket, message, BUFSIZE - 1, 0);
					char* nickName = (char*)malloc(sizeof(strlen(peerArray[arrIndex - 1].nickname)));
					strcpy(nickName, peerArray[arrIndex - 1].nickname);

					if ((strLen == 0) || (strLen == SOCKET_ERROR)) {
						closesocket(reads.fd_array[arrIndex]);

						printf("%s ", nickName);
						printf("closed\n");

						FD_CLR(reads.fd_array[arrIndex], &reads);

						for (int i = arrIndex; i < CheckPeerNumber; i++) {
							peerArray[i - 1].fd = peerArray[i].fd;
							peerArray[i - 1].Socket = peerArray[i].Socket;
							strcpy(peerArray[i - 1].nickname, peerArray[i].nickname);
						}

						CheckPeerNumber--;

						for (int i = 1; i < CheckPeerNumber + 1; i++)
						{
							send(reads.fd_array[i], nickName, strlen(nickName), 0);
							send(reads.fd_array[i], " logout\n", strlen("logout\n"), 0);
						} 
					}
					else { 
						for (int i = 0; i < reads.fd_count; i++)
							if (reads.fd_array[i] != hServSock && reads.fd_array[i] != hRecvClientSocket)
							{
								send(reads.fd_array[i], nickName, strlen(nickName), 0);
								send(reads.fd_array[i], ": ", strlen(": "), 0);
								send(reads.fd_array[i], message, strLen, 0);
							}
								
					}
				}
			}
		}
	}

	WSACleanup();

	return 0;
}
void ErrorHandling(char* message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}