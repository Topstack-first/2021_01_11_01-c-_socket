
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#define MSG_SIZE 4096
#define MAX_CLIENTS 95
#define MYPORT 7400

void exitClient(int fd, fd_set *readfds, char fd_array[], int *num_clients){
    int i;
    
    close(fd);
    FD_CLR(fd, readfds); //clear the leaving client from the set
    for (i = 0; i < (*num_clients) - 1; i++)
        if (fd_array[i] == fd)
            break;          
    for (; i < (*num_clients) - 1; i++)
        (fd_array[i]) = (fd_array[i + 1]);
    (*num_clients)--;
}


int main(int argc, char *argv[]) {
   int i=0;
   
   int port;
   int num_clients = 0;
   int server_sockfd, client_sockfd;
   struct sockaddr_in server_address;
   int addresslen = sizeof(struct sockaddr_in);
   int fd;
   char fd_array[MAX_CLIENTS];
   fd_set readfds, testfds, clientfds;
   char msg[MSG_SIZE];
   char temp[MSG_SIZE];    
   int result;
   
   /*Server==================================================*/
   if(argc==1 || argc == 2){
     if(argc==2){
      sscanf(argv[1],"%i",&port);
       
     }else port=MYPORT;
     
     printf("\n*** Server program starting (enter \"quit\" to stop): \n");
     fflush(stdout);

     /* Create and name a socket for the server */
     server_sockfd = socket(AF_INET, SOCK_STREAM, 0);
     server_address.sin_family = AF_INET;
     server_address.sin_addr.s_addr = htonl(INADDR_ANY);
     server_address.sin_port = htons(port);
     bind(server_sockfd, (struct sockaddr *)&server_address, addresslen);

     /* Create a connection queue and initialize a file descriptor set */
     listen(server_sockfd, 1);
     FD_ZERO(&readfds);
     FD_SET(server_sockfd, &readfds);
     FD_SET(0, &readfds);  /* Add keyboard to file descriptor set */
     
   
     /*  Now wait for clients and requests */
     while (1) {
        for (int i = 0; i < MSG_SIZE; i++)
			msg[i] = 0; 

        testfds = readfds;
        select(FD_SETSIZE, &testfds, NULL, NULL, NULL);
                    
        /* If there is activity, find which descriptor it's on using FD_ISSET */
        for (fd = 0; fd < FD_SETSIZE; fd++) {
           if (FD_ISSET(fd, &testfds)) {
              
              if (fd == server_sockfd) { /* Accept a new connection request */
                 client_sockfd = accept(server_sockfd, NULL, NULL);
                 /*printf("client_sockfd: %d\n",client_sockfd);*/
                
                                
                 if (num_clients < MAX_CLIENTS) {
                     FD_SET(client_sockfd, &readfds);
                     fd_array[num_clients]=client_sockfd;
                     /*Client ID*/
                     num_clients++;
                     printf("guest%d joined\n",client_sockfd);
                     fflush(stdout);

                     printf("server is ready to read from socket %d\n",client_sockfd);
                     printf("server is ready to write from socket %d\n", client_sockfd);

                     sprintf(msg,"connected as quest%d\n",client_sockfd);
                     send(client_sockfd, msg, strlen(msg), 0);
                 }
                 else {
                    sprintf(msg, "Sorry, too many clients.  Try again later.\n");
                    send(client_sockfd, msg, strlen(msg), 0);
                    close(client_sockfd);
                 }
              }
              else if(fd) {  /*Process Client specific activity*/
                 //printf("server - read\n");
                 //read data from open socket
                 result = recv(fd, msg, MSG_SIZE - 1, 0);
                 if(result==-1) perror("read()");
                 else if(result>0){
                    /*print to other clients*/
                    for(i=0;i<num_clients;i++){
                       if (fd_array[i] != fd)  /*dont write msg to same client*/
                       {
                          sprintf(temp,"quest%d :",fd);
                          send(fd_array[i],temp,strlen(temp),0);
                          send(fd_array[i],msg,strlen(msg),0);
                       }
                          
                    }
                 }                                   
              }                  
              else {  /* A client is leaving */
                 exitClient(fd,&readfds, fd_array,&num_clients);
              }//if
           }//if
        }//for
     }//while
  }//end Server code

}//main


